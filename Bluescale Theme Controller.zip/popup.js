document.addEventListener("DOMContentLoaded", () => {
  const bgPicker = document.getElementById("bgColorPicker");
  const textPicker = document.getElementById("textColorPicker");
  const themeToggle = document.getElementById("themeToggle");
  const resetBtn = document.getElementById("reset");

  const rgbToHex = (rgb) => {
    const [r, g, b] = rgb.match(/\d+/g).map(Number);
    return (
      "#" +
      [r, g, b].map((x) => x.toString(16).padStart(2, "0")).join("")
    );
  };

  const isHex = (val) => typeof val === "string" && /^#[0-9a-f]{6}$/i.test(val);
  const isRGB = (val) => typeof val === "string" && val.startsWith("rgb");

  const fallbackBg = "#141e32";
  const fallbackText = "#d2e6ff";
  const darkModeBg = "#202124"; // System dark theme
  const darkModeText = "#ffffff";
  const lightModeBg = "#f5f5f5"; // System light theme
  const lightModeText = "#222222";

  chrome.storage.sync.get(["bgColor", "textColor", "themeEnabled"], (data) => {
    let bg = data.bgColor;
    let text = data.textColor;
    const themeEnabled = data.themeEnabled !== false;

    if (isRGB(bg)) bg = rgbToHex(bg);
    if (isRGB(text)) text = rgbToHex(text);
    if (!isHex(bg)) bg = fallbackBg;
    if (!isHex(text)) text = fallbackText;

    bgPicker.value = bg;
    textPicker.value = text;
    themeToggle.checked = themeEnabled;

    updatePopupTheme(bg, text, themeEnabled);
    applyColorsToPage(bg, text, themeEnabled);
  });

  function applyColorsToPage(bg, text, themeEnabled) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: (bg, text, themeEnabled) => {
          if (themeEnabled) {
            document.documentElement.style.setProperty("--bg-color", bg);
            document.documentElement.style.setProperty("--text-color", text);
            document.documentElement.classList.add("blue-mode"); // Instant toggle
          } else {
            document.documentElement.classList.remove("blue-mode");
            document.documentElement.style.removeProperty("--bg-color");
            document.documentElement.style.removeProperty("--text-color");
          }
        },
        args: [bg, text, themeEnabled]
      });
    });
  }

  function updatePopupTheme(bg, text, themeEnabled) {
    const systemDarkMode = window.matchMedia("(prefers-color-scheme: dark)").matches;
    document.body.style.backgroundColor = themeEnabled ? bg : systemDarkMode ? darkModeBg : lightModeBg;
    document.body.style.color = themeEnabled ? text : systemDarkMode ? darkModeText : lightModeText;
  }

  bgPicker.addEventListener("input", () => {
    const bg = bgPicker.value;
    const text = textPicker.value;
    chrome.storage.sync.set({ bgColor: bg, textColor: text });

    updatePopupTheme(bg, text, themeToggle.checked);
    applyColorsToPage(bg, text, themeToggle.checked);
  });

  textPicker.addEventListener("input", () => {
    const bg = bgPicker.value;
    const text = textPicker.value;
    chrome.storage.sync.set({ bgColor: bg, textColor: text });

    updatePopupTheme(bg, text, themeToggle.checked);
    applyColorsToPage(bg, text, themeToggle.checked);
  });

  themeToggle.addEventListener("change", () => {
    const enabled = themeToggle.checked;
    chrome.storage.sync.set({ themeEnabled: enabled });

    updatePopupTheme(bgPicker.value, textPicker.value, enabled);
    applyColorsToPage(bgPicker.value, textPicker.value, enabled);
  });

  resetBtn.addEventListener("click", () => {
    bgPicker.value = fallbackBg;
    textPicker.value = fallbackText;
    chrome.storage.sync.set({ bgColor: fallbackBg, textColor: fallbackText });

    updatePopupTheme(fallbackBg, fallbackText, themeToggle.checked);
    applyColorsToPage(fallbackBg, fallbackText, themeToggle.checked);
  });
});